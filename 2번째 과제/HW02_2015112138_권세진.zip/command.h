int ls(char* factor);
int mkdir(char* factor);

